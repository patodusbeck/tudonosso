const Discord = require('discord.js');
const client = new Discord.Client({ intents: 3276799 });

const config = require('./config');
const { connect, mongoose } = require('mongoose');
const { ActivityType } = require('discord.js');

const { loadEvents } = require('./Handlers/eventHandler');
const { loadCommands } = require('./Handlers/commandHandler');

require('colors');

client.commands = new Discord.Collection();
client.buttons = new Discord.Collection();
client.selectMenus = new Discord.Collection();
client.modals = new Discord.Collection();

const antiCrash = require('./Utils/antiCrash.js');

client
    .login(config.token)
    .then(() => {
        console.clear();

        antiCrash(client);

        console.log(
            '[Discord API] '.green +
            client.user.username +
            ' foi logado com sucesso.'
        );

        mongoose.set('strictQuery', true);

        connect(config.database, {})
            .then(() => {
                console.log('✦ Database '.green + 'em operação.');

                loadEvents(client);
                loadCommands(client);
            });
    })
    .catch((err) => console.log(err));

const status = [
    {
        name: config.oneac,
        type: Discord.ActivityType.Listening,
        url: 'https://www.twitch.tv/discord',
    },
    {
        name: config.twoac,
        type: Discord.ActivityType.Streaming,
        url: 'https://www.twitch.tv/discord',
    },
    {
        name: config.threeac,
        type: Discord.ActivityType.Streaming,
        url: 'https://www.twitch.tv/discord',
    },
];

client.on('ready', (c) => {
    console.clear();

    console.log('✦ Kaxcav Studios </> - Online!');
    console.log('𝔓𝔄𝔗𝔒 𝔇𝔘𝔖 𝔅𝔈ℭ𝔎');

    setInterval(() => {
        let random = Math.floor(Math.random() * status.length);
        client.user.setActivity(status[random]);
    }, 5000);

    client.user.setStatus('idle');
});
